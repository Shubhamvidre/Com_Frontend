 let users=[
 {uId:101,name:"ajay",salary:3000},    
 {uId:102,name:"pooja",salary:4000},
 {uId:103,name:"kavita",salary:5000},
 {uId:104,name:"deepa",salary:6000},
 {uId:105,name:"Ram",salary:8000}
 ]
 
   
 let flag=false;
 let id=102;
 
 let data=users.filter((temp)=>  {
 
 if(temp.uId==id)
 {
     flag=true 
 }
 else{
    return temp;
 }
 

 } )

 if(flag==false)
 {
    console.log("not Found ...")
 }
 else{
    console.log("Removed..........")
 }

