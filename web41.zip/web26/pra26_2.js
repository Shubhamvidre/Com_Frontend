let pics=["imp1.jpg","imp2.png","imp3.jpg","imp4.png","imp5.png"]
let c=0;

const handleNext=()=>
{

c=c+1;

if(c>pics.length-1)
{
  c=0;
}
document.getElementById("pic").src=pics[c];


}
const handlePre=()=>
{

c=c-1;

if(c<0)
{
  c=pics.length-1;
}
document.getElementById("pic").src=pics[c];


}

const start=()=>
{

document.getElementById("t2").style="height:100px; width:200px";


}



const stop=()=>
{

document.getElementById("t2").style="height:200px; width:200px";


}