const show=()=>
{
    let out=""

     let k=document.getElementById("ds");
     let js=document.getElementById("js");
     let c=document.getElementById("c");
     let java=document.getElementById("java");
     let Python=document.getElementById("python");

     if(k.checked==true)
     {
        out=out+"DS"
     }
     if(js.checked==true)
     {
        out=out+"JS"
     }
     if(c.checked==true)
     {
        out=out+"C"
     }
     if(java.checked==true)
     {
        out=out+"Java"
     }
     if(Python.checked==true)
     {
        out=out+"Python"
     }
     document.getElementById('t1').innerHTML=out
    }