function showTime()
{
let d= new Date()

let temp=d.toLocaleTimeString();
 document.getElementById("t1").innerHTML=temp;

}
setInterval(showTime,1000)
function newfun()
{
    document.getElementById("t1").innerHTML="Hi Everyone";
}
setTimeout(newFun,1000)

