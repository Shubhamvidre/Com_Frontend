let tp1=0
function dice1()
{
    let r=Math.floor(Math.random()* 6)+1;
    tp1=tp1+r;
    document.getElementById("d").innerHTML=r;
    document.getElementById("tp1").innerHTML=tp1; 

}