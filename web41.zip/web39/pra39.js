let Car1={
    CarNo:2011,
    CarName:"BMW",
    ModeYear:2023,

}

let Car2=
{
    CarNo:5011,
    CarName:"Audi",
    ModeYear:2021,
}

let show=function() {
        
    console.log(`Car Number is ${this.CarNo} Car name is ${this.CarName} Car Model of year is ${this.ModeYear}`)
}

let data=show.bind(Car1,"Jeep")

data()