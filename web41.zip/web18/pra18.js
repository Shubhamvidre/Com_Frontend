let str=""
let num1,num2,result,opt;
function handleNumber(num)
{

      str=str+num;
     document.getElementById("t1").innerHTML=str;

}

function handleOp(op)
{
  
    opt=op;
   num1=parseInt(str);   
   document.getElementById("t1").innerHTML="";
   str="";
   console.log(num1);


}



function cal()
{
    num2=parseInt(str);  
    
    if(opt=='+')
    {
        result=num1+num2;
    }
    else if(opt=='-')
    {
        result=num1+num2;


    }
    else if(opt=='/')
    {
        result=num1/num2;


    }
    else if(opt=='*')
    {
        result=num1*num2;


    }

  document.getElementById("t1").innerHTML=result;

}
/*
function clear()
{
    let bNo=document.getElementById("t1").value;
    document.getElementById("t1").remove;
}*/