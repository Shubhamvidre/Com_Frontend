function addBk()
{
let code=document.getElementById("t4").value;
let name=document.getElementById("t1").value;
let qty=document.getElementById("t2").value;
let price=document.getElementById("t3").value;


let book={name,qty,price}

book=JSON.stringify(book)
localStorage.setItem(code,book)


}



function bill()
{
   let b=0;
  let code=document.getElementById("t4").value;

  let qty=document.getElementById("t2").value;

  let book= JSON.parse(localStorage.getItem(code))
  if(qty>book.qty)
  {
    alert("less qty ")
  }
  else
  {
   b=qty*book.price
   document.getElementById("t5").innerHTML=book.price;
   

  }

}

const remove=()=>
{
    let code=document.getElementById("t1").value;
    if(code!=null)
    {
        localStorage.removeItem(code);
        alert("book removed");
    }
    else
    {
        alert("invalid book code");
    }
}

function update()
{


  let code=document.getElementById("t1").value;
  if(code!=null)
  {
      
    let name=document.getElementById("t1").value;
    let qty=document.getElementById("t2").value;
    let price=document.getElementById("t3").value;

     let book={name,qty,price}
      book=JSON.stringify(book)
     localStorage.setItem(code,book)
      alert("book updated");
  }
  else
  {
      alert("invalid book code");
  }


}