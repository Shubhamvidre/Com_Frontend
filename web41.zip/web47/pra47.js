fetch("https://jsonplaceholder.typicode.com/posts")
.then((data)=>  console.log(data.json()))
.catch((e)=> console.log("data is not there....") )