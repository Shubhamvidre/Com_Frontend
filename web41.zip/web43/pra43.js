const cal=(a,b,sum,sub)=>
{

      sum(a,b)
  

}
const sum=(a,b)=>
{
  console.log(a+b)

}

const sub=(a,b)=>
{
  console.log(a-b)

}


cal(6,2,sub)
//cal(3,5,sum)


/*cal(8,4,(a,b)=>
{
  console.log(a*b)
})*/

cal(8,4,(a,b)=>
{
    console.log(a/b)
})

