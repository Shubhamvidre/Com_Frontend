let books=[{bno:101,name:"abc DS",price:200},
{bno:102,name:"xyz DS",price:400},
{bno:103,name:"ghk JS",price:500},
{bno:104,name:"lmn DBMS",price:800},
{bno:105,name:"pqr DS",price:900},
{bno:106,name:"OS",price:100}]

//books.map(( temp)=> console.log(` name of the book is ${temp.name}  price of book id  ${temp.price}       `) )

//let dat=books.filter((temp)=>  temp.name.includes("DS"))

//console.log(dat)

//let data=books.filter((temp)=>   temp.price==500    )
//console.log(data)

//let bn=prompt("Enter book Number You want to search")
//let data=books.filter((temp)=>   temp.price==bn   )
//console.log(data)

//Search price by name
//let nm=prompt("Enter book name You want to search")
//let data=books.filter((temp)=>   temp.name==nm  )
//console.log(data)

//let bn=prompt("enter book name which u want to  search ")
//let data=books.filter((temp)=> temp.name.toLowerCase().includes(bn.toLocaleLowerCase()) )
//console.log(data)

/*let bn=parseInt(prompt("enter book number which u dont want to  search "))
let data =books.filter((temp)=>  temp.bno!=bn )
books=data;
console.log(books)
*/

/*
let nm=prompt("enter book number which u want to  search ")
let data =books.filter((temp)=>  !temp.name.toLowerCase().includes(nm.toLowerCase()))
books=data;
console.log(books)
*/


let bn=parseInt(prompt("enter book number which u want to  search "))
let pr=parseInt(prompt("enter book  new price of book  "))


   let data=books.filter((temp)=>  {

       if(temp.bno==bn)
       {
         return temp.price=pr;
       }
       else{
        return temp;
       }
   }    )
   console.log(data)
   