let users=["imp1.jpg","imp2.jpg","imp3.jpg","imp4.jpg","imp5.jpg"]
function show()
{
let k=Math.floor(Math.random()* users.length-1)+0;
document.getElementById("s1").src=users[k];
}
function show2()
{
let k=Math.floor(Math.random()* users.length-1)+0;
document.getElementById("s2").src=users[k];
}
function show3()
{
let k=Math.floor(Math.random()* users.length-1)+0;
document.getElementById("s3").src=users[k];
}