const show=()=>
{

   let val=document.getElementById("dept");
   console.log(val.value)



}