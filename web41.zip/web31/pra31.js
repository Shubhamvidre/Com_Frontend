const show=()=>
{

     if(document.getElementById("it").checked)
     {
      console.log("u  will get all question from the java script ")
     }



     if(document.getElementById("nit").checked)
     {
      console.log("u  will get all question from the DBMS ")
     }




}