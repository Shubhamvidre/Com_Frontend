let hr=0,min=0,ms=0;
function start()
{
    const sta=document.getElementById('t1').value;
    
}