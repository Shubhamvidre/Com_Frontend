function signIn()
{

    let uId=document.getElementById("t1").value;

    let uPass=document.getElementById("t2").value;


    if(uId=="mom" && uPass=="dad")
    {
    alert("welcome");
    }
    else{
        alert("not welcome");
    }



}