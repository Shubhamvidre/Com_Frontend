//function inside the object
const sum=(a,b,...l)=>
{
  let s=0;
  s=a+b;
  for(let i=0;i<l.length;i=i+1)
  {
    s=s+l[i]
  }


  return (s)
}




let c=sum(3,4,8,9)
console.log(c)






