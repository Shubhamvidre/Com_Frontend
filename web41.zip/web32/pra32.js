const show=()=>
{
    let b=0;
    let sal=document.getElementById("sal").value
   if(document.getElementById("sale").checked)
   {
    b=sal*5/100
   }
    
   else if(document.getElementById("mark").checked)
   {
    b=sal*10/100
   }
   

   let total=sal+b;


     document.getElementById("bn").innerHTML=b;
     document.getElementById("t").innerHTML=total;
}