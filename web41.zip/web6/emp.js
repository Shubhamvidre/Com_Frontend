function employe()
{
    
    uName=document.getElementById("t1").value;
    uSal=document.getElementById("t2").value;

    bon=parseFloat(uSal*5/100);
    document.getElementById("t3").value=bon;

    tSal=parseFloat(uSal)+parseFloat(bon);
    document.getElementById("t4").value=tSal;




}