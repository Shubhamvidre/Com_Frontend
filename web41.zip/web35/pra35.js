let users=[]

const add=()=>
{
    let temp=  JSON.parse(localStorage.getItem("list"))

let Roll=document.getElementById("rno").value
let Name=document.getElementById("nm").value
let Sci=document.getElementById("sci").value
let Maths=document.getElementById("maths").value
let Hindi=document.getElementById("hd").value
let Eng=document.getElementById("eng").value
let user={Roll,Name,Sci,Maths,Hindi,Eng}
if(temp==null)
{
   users=[...users,user]
}
else{
 users=temp;
 users=[...users,user]

}
localStorage.setItem("list", JSON.stringify(users))
}



const search=()=>
{
   
  let rno=document.getElementById("rno").value
   let temp=  JSON.parse(localStorage.getItem("list"))
   if(temp==null)
   {
      alert("list is empty")
   }

  else{

   users=temp;

   let data=users.filter((user)=> user.Roll==rno )

   if(data.length==0)
   {
      alert("not found in list ...")
   }
  
   else{
  document.getElementById("nm").value= data[0].Name
  document.getElementById("sci").value = data[0].Sci
  document.getElementById("maths").value = data[0].Maths
  document.getElementById("eng").value = data[0].Eng
  document.getElementById("hd").value = data[0].Hindi

  }
}

}

const remove=()=>
{


   let rno=document.getElementById("rno").value
   let temp=  JSON.parse(localStorage.getItem("list"))

  if(temp==null)
  {
   alert("list is empty")
  }

  else{


    users=temp;
    let data =users.filter((user)=>  user.Roll!=rno)
    users=data;
    localStorage.setItem("list", JSON.stringify(users))
  }
}



const updateS=()=>
{
 
   let users=  JSON.parse(localStorage.getItem("list"))

   let data=users.filter ((user)=>
   {
    if(user.Roll=="107")
    {
      
      return user.Name="aaaaaaaaaaaaa";
    }
    else{
    return   users;
    }

   })
   users=data

    localStorage.setItem("list", JSON.stringify(users))


   console.log(data)
}

document.getElementById(fg).style.forgr