const show=()=>
{
    let temp=  JSON.parse(localStorage.getItem("list"))

  document.getElementById("t1").value= data[0].Name
  document.getElementById("sci").value = data[0].Sci
  document.getElementById("maths").value = data[0].Maths
  document.getElementById("eng").value = data[0].Eng
  document.getElementById("hd").value = data[0].Hindi
}