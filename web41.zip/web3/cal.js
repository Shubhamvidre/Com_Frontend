function sum()
{
    let a,b,c;

    a=document.getElementById("t1").value;
    b=document.getElementById("t2").value;
    c=  parseInt(a)+ parseInt(b);
    document.getElementById("t3").value=c;



}