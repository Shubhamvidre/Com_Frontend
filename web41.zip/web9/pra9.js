function changeBG(clr)
{

    document.getElementById("main").style.backgroundColor = clr;

    
}