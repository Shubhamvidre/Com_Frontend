function theme1()
{
    document.getElementById("bg").style.backgroundColor="pink"
    document.getElementById("t1").style.color="blue"
    document.getElementById("t2").style.color="blue"
    document.getElementById("t3").style.color="blue"
    document.getElementById("t4").style.color="blue"
}
function theme2()
{
    document.getElementById("bg").style.backgroundColor="yellow"
    document.getElementById("t1").style.color="red"
    document.getElementById("t2").style.color="red"
    document.getElementById("t3").style.color="red"
    document.getElementById("t4").style.color="red"
}
function theme3()
{
    document.getElementById("bg").style.backgroundColor="orange"
    document.getElementById("t1").style.color="green"
    document.getElementById("t2").style.color="green"
    document.getElementById("t3").style.color="green"
    document.getElementById("t4").style.color="green"
}