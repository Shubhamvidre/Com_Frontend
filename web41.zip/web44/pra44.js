const getChesse=(callback)=>
{
   let chesse;

  setTimeout(()=>   {
    chesse="got chesse"
    callback(chesse)
   }
     
,3000)   

 

}


getChesse((chesse)=> console.log(chesse))