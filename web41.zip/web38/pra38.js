const deatil=(age,name,...skills)=>
{
  console.log(age+' '+name+" "+skills)
  skills.map((temp)=>console.log(temp))
}
deatil(22,"Tim","Python","java")
