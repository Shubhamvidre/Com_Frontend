class Person
{

 constructor(age,name)
 {
  this.age=age;
  this.name=name;
  
 }


 show1=()=>
 {
  console.log(`Age: ${this.age} Name : ${this.name} `)
 }


}

class Student extends Person
{

  constructor(roll,marks,age,name)
  {
     super(age,name)

    this.roll=roll;
    this.marks=marks

  }

  show=()=>
  {
   
    console.log(`Roll: ${this.roll} marks : ${this.marks} `)

  }




}







const s1=new Student(101,90,21,"asha")
s1.show1()
s1.show()