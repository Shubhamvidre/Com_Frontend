let users=["asha","pooja","nikunj","ishika","shiva","arti"]
    let password=[101,102,103,104,105,106]
function log()
{
    

    i=document.getElementById("t1").value;
    p=parseInt(document.getElementById("t2").value);
    
    let id = users.indexOf(i);
    let pa=password.indexOf(p);
    if(id==pa && id!=-1 && pa!=-1)
    {
    alert("welcome");
    }
    else{
        alert("not welcome");
    }


}
function res(){
    
    i=document.getElementById("t1").value;
    p=parseInt(document.getElementById("t2").value);
    
    let id = users.indexOf(i);
    let pa=password.indexOf(p);
    if(id==pa && id!=-1 && pa!=-1)
    {
        users.splice(i,1);
        password.splice(p,1);
        alert("user removed");
    }
    else{
        alert("not welcome");
    }
    
}