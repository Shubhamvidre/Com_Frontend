const upperLetters = "ABCDEFGHIJKLMNOPQSRTUVWXYZ";
const lowerLetters = "abcdefghijklmnopqrstuvwxyz";
const numbers = "0123456789";
const symbol = "~!@#$%^&*()_+=|";

function giveUCL()
{

  let r=Math.floor(Math.random() * 25) + 0;

   let k=  upperLetters[r]
   return(k)

}

function giveLCL()
{

  let r=Math.floor(Math.random() * 25) + 0;

   let k=  lowerLetters[r]
   return(k)

}
function giveNUM()
{

  let r=Math.floor(Math.random() * 9) + 0;

   let k=  numbers[r]
   return(k)

}

function giveSym()
{
  
  let r=Math.floor(Math.random() * symbol.length-1) + 0;

   let k=  symbol[r]
   return(k)

}

function  GenPass()
{
  let  pass=""
 let  len=parseInt(document.getElementById("len").value)
 let ucl="",lcl="",ncl="",scl="";

   while(true)
   {
    while (pass.length < len) {
        if (document.getElementById("upper").checked) {
          pass += giveUCL();
        }
    
        if (pass.length >= len) break;
    
        if (document.getElementById("lower").checked) {
          pass += giveLCL();
        }
    
        if (pass.length >= len) break;
    
        if (document.getElementById("number").checked) {
          pass += giveNUM();
        }
    
        if (pass.length >= len) break;
    
        if (document.getElementById("symbol").checked) {
          pass += giveSym();
        }
      }
      console.log(pass);
    }
   }
  





