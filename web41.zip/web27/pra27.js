const show=()=>
{


     let k=document.getElementById("st");

     if(k.checked==true)
     {
      alert("student")
     }
     



     let p=document.getElementById("t");
     if (p.checked==true)
     {

      alert("Teacher")

     }

     
     

     }


