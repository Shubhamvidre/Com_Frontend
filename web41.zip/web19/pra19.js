function submitF()
{
    let  name=document.getElementById("nm").value;
    
      if(name.length==0)
      {
       document.getElementById("enm").innerHTML="name can not be empty"


      }

    let pass=document.getElementById("tm").value;

       if(pass.length<5)
       {
        document.getElementById("pnm").innerHTML="Password cannot be less then 5 letter"

       }
    let age=document.getElementById("am").value;
    
   
         if(age>18 && age<35){
            alert("valid age")
         }
         else
         {
            document.getElementById("anm").innerHTML="Age should be between 18 and 35"
         }
         
        


}