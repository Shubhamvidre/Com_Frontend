const show=()=>
{

   let val=document.getElementById("dept").value;
    let d=0;
    let amt=document.getElementById("bill").value
   if(val=="Student")
   {

        dis=amt*5/100;
   }

   else{

      dis=amt*10/100;

   }

   let fBill=amt-dis;


     document.getElementById("fbill").innerHTML=fBill;
}