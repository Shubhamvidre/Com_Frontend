let users=[{name:"asha",fee:2000,sub:"ds"},
{name:"ajay",fee:400,sub:"c++"},
{name:"tim",fee:500,sub:"dbms"},
{name:"jack",fee:7000,sub:"js"}
]

users.map(( temp)=> console.log(` ur name isd ${temp.name}  ur subject is  ${temp.sub}       `) )