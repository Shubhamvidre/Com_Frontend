let payment=0;
let flag=false;
const pay= new Promise(function(resolve,reject)

{

    if(payment>0)
    {
        
        flag=true;
        
    }
    else if(payment==0){

    }

   if(flag==true)
   {
      resolve("payment not recieved ")
   }

    else{

        let payment=0;
        let flag=false;
        const pay= new Promise(function(resolve,reject)
        
        {
        
            if(payment>0)
            {
                flag=true;
                
            }
            
        
           if(flag==false)
           {
              resolve("payment not recieved ")
           }
        
            else{
        
              reject("payment revieved............")
            }
        
        
        })
        
        
        
        pay.then((data)=> console.log(" "+ data) ).catch((erro)=>  console.log(erro))
    }


})



pay.then((data)=> console.log(" "+ data) ).catch((erro)=>  console.log(erro))