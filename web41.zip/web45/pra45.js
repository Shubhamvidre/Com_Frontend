const movieTicket= new Promise(function(resolve,reject)
{

    let flag=false;

   if(flag==true)
   {
      resolve("you got tickets ")
   }

    else{

      reject("tickets is not there............")
    }


})


//console.log(movieTicket)
movieTicket.then((data)=> console.log(" "+ data) ).catch((erro)=>  console.log(erro))