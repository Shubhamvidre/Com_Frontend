const addBook=()=>
{

  let bNo=document.getElementById("t1").value;
  let bName=document.getElementById("t2").value;

  let bPrice=document.getElementById("t3").value;

  let bQty=document.getElementById("t4").value;

   
let book=
{

   bName,
   bPrice,
   bQty
}

book=  JSON.stringify(book);


localStorage.setItem(bNo,book);


}

const search=()=>
{

   let bNo=document.getElementById("t1").value;

    let data = localStorage.getItem(bNo)

    data=JSON.parse(data)
    console.log(data.bName)

}
const removeBook=()=>
{
    let bNo=document.getElementById("t1").value;

   localStorage.removeItem(bNo)
}


const updateBook=()=>
{
    let bNo=document.getElementById("t1").value;
    let bName=document.getElementById("t2").value;
    let ts=localStorage.getItem(bName)
    let dat = localStorage.getItem(bNo)
    if(dat==ts){
        localStorage.setItem(bPrice)
        console.log(dat.bPrice)
    }
    
    
}

const bill=()=>
{
    let bNo=document.getElementById("t1").value;
    let b,p,q;
    let data = localStorage.getItem(bNo)
    data=JSON.parse(data)
    console.log(data.bPrice*data.bQty)
}
