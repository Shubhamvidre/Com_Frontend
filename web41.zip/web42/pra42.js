const start=()=>
{
  document.getElementById("start").style.display="none"
  document.getElementById("stop").style.visibility="visible"

}

const stop=()=>
{
    document.getElementById("stop").style.visibility="hidden"
    document.getElementById("start").style.display="block"
    
}

const submit=()=>
{
  document.getElementById("stop").style.display="block"
  document.getElementById("start").style.visibility="hidden"

}



