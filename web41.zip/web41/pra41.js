let data=["java","c++","python","dbms","script","react","nodejs","mongodb"]

let rw=""
let uw=""
const show=()=>
{

let l= parseInt(data.length-1);
let r=Math.floor(Math.random() * l) + 0;

rw=data[r]

let temp=rw.split('')

let t1 = parseInt(temp.length-1)

console.log(temp)




let i;

 for(i=1;i<=2;i=i+1)
 {
  
  let r1=Math.floor(Math.random() * t1) + 0;

  let r2=Math.floor(Math.random() * t1) + 0;


    t=temp[r1]
    temp[r1]=temp[r2]
    temp[r2]=t
     

 }



document.getElementById("jw").innerHTML=temp.join("")

}

const check=()=>
{

uw=document.getElementById("t1").value
if(uw==rw)
{
  alert("correct......")
}

else{
  alert("Next ......")
}
}

const showc=()=>
{
 uw=document.getElementById("t1").value
if(uw==rw)
{
  alert("correct......")
}

else{
  document.getElementById("r").innerHTML=rw;
}
}

let seconds = 60;

const time = () => {
    console.clear();
    if (seconds > 0) {
        console.log(seconds);
        seconds -= 1;
        setTimeout(makeIteration, 1000);  // 1 second waiting
    } else {
      
        console.log('Done!');
    }
};

setTimeout(makeIteration, 1000);






