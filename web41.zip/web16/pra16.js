//HW to add update password
const signUp=()=>
{
let uid=document.getElementById("t1").value;


let upass=document.getElementById("t2").value;

   localStorage.setItem(uid,upass)
}

const signIn=()=>
{
let uid=document.getElementById("t1").value;
let upass=document.getElementById("t2").value;
let p=localStorage.getItem(uid);
if(p==upass)
{
   alert("welcome")
}
else{
   alert("not welcome")
}
}
const removeIn=()=>
{


   let uid=document.getElementById("t1").value;


let upass=document.getElementById("t2").value;


let p=localStorage.getItem(uid);
if(p==upass)
{
   localStorage.removeItem(uid)

}

else{
   alert("Invalid user.......")
}

}

const updatePass=()=>
{
   
}