/*let users=["js","os","ds","c++"]


let bk =prompt("enter new book  name ")




users=[bk,...users]


users.map((temp)=>  console.log(temp))*/







let books=[{bno:101,bname:"ds",qty:20},{bno:102,name:"os",qty:90},{bno:104,name:"c++",qty:10}]


//take new book information add in ur list 

let bname=prompt("enter ur book name ")
let bno=prompt("enter book number")
let qty=prompt("enter ur qty")


let book={bno,bname,qty}

books=[...books,book]

books.map((temp)=>  console.log(temp))