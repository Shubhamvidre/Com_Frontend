function cube()
{
    let a,b;

    a=document.getElementById("t1").value;
   
    c=  parseInt(a*a*a);
    document.getElementById("t3").value=c;



}