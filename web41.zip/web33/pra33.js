let out=0;
let b=0;
let to=0;
let d=0;

const sita=()=>
{
     let val=document.getElementById("sz").value;
    
   if(val=="Small")
   {

        b=100;
   }

   else if(val=="Med"){

      b=200;

   }
   else if(val=="Large")
   {
     b=300;
   }
   document.getElementById("b").innerHTML=b;
}

const topping=()=>
{
     if(document.getElementById("capsicum").checked)
     {
          out=out+20;
     }
     
     if(document.getElementById("onion").checked)
     {
          out=out+30;
     }
     if(document.getElementById("mushroom").checked)
     {
          out=out+50;
     }
     if(document.getElementById("panner").checked)
     {
          out=out+100;
     }
      to=b+out;
     document.getElementById("t2").innerHTML=out;
     document.getElementById("t1").innerHTML=to;

}
const show=()=>

{
     
   if(document.getElementById("nmem").checked)
   {
    d=to*5/100;
   }
    
   else if(document.getElementById("mem").checked)
   {
    d=to*10/100;
   }
   else{
     console.log("hi")
     d=0;
   }
   

   let total=to-d;


     document.getElementById("d").innerHTML=d;
     document.getElementById("total").innerHTML=total;
}