function employe()
{
    
    uName=document.getElementById("t1").value;
    uSal=document.getElementById("t2").value;
    uhol=document.getElementById("t3").value;
    uholamt=document.getElementById("t4").value;

    bon=parseFloat(uSal*5/100);
    document.getElementById("t5").value=bon;

    tSal=parseFloat(uSal)+parseFloat(bon)-parseFloat(uhol*uholamt);
    document.getElementById("t6").value=tSal;




}